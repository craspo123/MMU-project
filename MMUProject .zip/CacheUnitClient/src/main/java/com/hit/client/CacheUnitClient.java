package com.hit.client;

import java.io.ObjectOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.HashMap;

//Its function is to communicate with the server
public class CacheUnitClient {

	public String send(String request) {

		try {
			// Connect to server and open communication
			Socket clientSocket = new Socket("localhost", 12345);// localhost -> ip server

			ObjectOutputStream toServer = new ObjectOutputStream(clientSocket.getOutputStream());
			ObjectInputStream fromServer = new ObjectInputStream(clientSocket.getInputStream());

			toServer.writeObject(request);
			HashMap<String, String> serverAnswer = (HashMap<String, String>) fromServer.readObject();
			return parseAnswer(serverAnswer);
			
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return null;
	}

	//Parsing the server answer to string
	private String parseAnswer(HashMap<String, String> serverAnswer) {
		String answer = "action:" + serverAnswer.get("action") + ","
						+ "Result:" + serverAnswer.get("Result") + ",";

		if (serverAnswer.get("action").equals("STATISTICS")) {
			answer += "Capacity:" + serverAnswer.get("Capacity") + ","
					+ "Algo:" + serverAnswer.get("Algo") + ","
					+ "DataModel:" + serverAnswer.get("DataModel") + ","
					+ "Request:" + serverAnswer.get("Request")+ ","
					+ "Swaps:" + serverAnswer.get("Swaps");
		}
		return answer;
	}
}
