package com.hit.client;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import com.hit.view.CacheUnitView;

public class CacheUnitClientObserver implements PropertyChangeListener {

	private CacheUnitClient client;

	public CacheUnitClientObserver() {
		client = new CacheUnitClient();
	}

	@Override
	public void propertyChange(PropertyChangeEvent evt) {

		if (evt.getSource() instanceof CacheUnitView) {
			CacheUnitView view = (CacheUnitView) evt.getSource();
			String answerFormServer=client.send(evt.getNewValue().toString());
			view.updateUIData(answerFormServer);
		}
	}
}
