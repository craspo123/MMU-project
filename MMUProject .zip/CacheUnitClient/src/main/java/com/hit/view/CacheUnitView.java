package com.hit.view;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.GroupLayout.Alignment;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

public class CacheUnitView {

	private PropertyChangeSupport listener=new PropertyChangeSupport(this); 
	private JTextArea StatisticsET;
	private int xx, xy;
	private JFrame main;

	public void start() {

		//create new frame
		main= new JFrame();
		main.setResizable(false);
		main.setUndecorated(true);
		main.setSize(1040, 440);

		//center app in screen
		Toolkit tk = main.getToolkit();
		Dimension dim = tk.getScreenSize();
		int x = (int) dim.getWidth() / 2 - main.getWidth() / 2;
		int y = (int) dim.getHeight() / 2 - main.getHeight() / 2;
		main.setLocation(x, y);

		JPanel contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new LineBorder(new Color(75, 150, 255), 2, true));
		main.setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(1, 2, 0, 0));

		JPanel panel = new JPanel();
		contentPane.add(panel);
		panel.setLayout(new GridLayout(2, 1, 0, 0));

		JPanel panel_1 = new JPanel();
		panel.add(panel_1);
		panel_1.setLayout(new BoxLayout(panel_1, BoxLayout.X_AXIS));

		//set image and drag operation
		JLabel image = new JLabel("");
		panel_1.add(image);
		image.setIcon(new ImageIcon(CacheUnitView.class.getResource("/images/MMUBackground.jpg")));
		image.setAlignmentX(Component.CENTER_ALIGNMENT);
		image.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				xx = e.getX();
				xy = e.getY();
			}
		});
		image.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				int x = e.getXOnScreen();
				int y = e.getYOnScreen();
				main.setLocation(x - xx, y - xy);
			}
		});

		//panel for about labels
		JPanel welcomPanel = new JPanel();
		panel.add(welcomPanel);
		welcomPanel.setBackground(Color.DARK_GRAY);
		welcomPanel.setLayout(new GridLayout(6, 1, 0, 0));

		JLabel welcome_lbl = new JLabel("Welcom To MMU APP");
		welcome_lbl.setHorizontalAlignment(SwingConstants.CENTER);
		welcome_lbl.setFont(new Font("Tahoma", Font.PLAIN, 25));
		welcome_lbl.setForeground(Color.WHITE);
		welcome_lbl.setAlignmentX(Component.CENTER_ALIGNMENT);
		welcomPanel.add(welcome_lbl);

		JLabel Copyrights_lbl1 = new JLabel("created by");
		Copyrights_lbl1.setAlignmentX(Component.CENTER_ALIGNMENT);
		Copyrights_lbl1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		Copyrights_lbl1.setForeground(Color.GRAY);
		Copyrights_lbl1.setHorizontalAlignment(SwingConstants.CENTER);
		welcomPanel.add(Copyrights_lbl1);

		JLabel Copyrights_lbl2 = new JLabel("Daniel Sorani");
		Copyrights_lbl2.setFont(new Font("Tahoma", Font.BOLD, 16));
		Copyrights_lbl2.setHorizontalAlignment(SwingConstants.CENTER);
		Copyrights_lbl2.setForeground(Color.GRAY);
		Copyrights_lbl2.setAlignmentX(Component.CENTER_ALIGNMENT);
		welcomPanel.add(Copyrights_lbl2);

		//top panel
		JPanel topPanel = new JPanel();
		topPanel.setBorder(new LineBorder(new Color(0, 0, 0), 2, true));
		topPanel.setBackground(Color.WHITE);
		contentPane.add(topPanel);

		JPanel panel_stat = new JPanel();
		panel_stat.setForeground(Color.WHITE);
		panel_stat.setBackground(Color.WHITE);
		panel_stat.setLayout(new FlowLayout(FlowLayout.RIGHT, 5, 5));
		panel_stat.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				xx = e.getX() + main.getWidth() / 2;
				xy = e.getY();
			}
		});
		panel_stat.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				int x = e.getXOnScreen();
				int y = e.getYOnScreen();
				main.setLocation(x - xx, y - xy);
			}
		});

		JLabel exitBtn = new JLabel("X ");
		panel_stat.add(exitBtn);
		exitBtn.setForeground(Color.BLACK);
		exitBtn.setHorizontalAlignment(SwingConstants.RIGHT);
		exitBtn.setFont(new Font("Tahoma", Font.BOLD, 25));
		exitBtn.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseEntered(MouseEvent e) {
				super.mouseEntered(e);
				exitBtn.setForeground(Color.RED);
			}

			@Override
			public void mouseExited(MouseEvent e) {
				super.mouseExited(e);
				exitBtn.setForeground(Color.BLACK);

			}

			@Override
			public void mouseClicked(MouseEvent arg0) {
				System.exit(0);
			}
		});

		JPanel panel_r1 = new JPanel();
		panel_r1.setBackground(Color.WHITE);
		panel_r1.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));

		JLabel Statisticslbl = new JLabel("  Statistics:");
		panel_r1.add(Statisticslbl);
		Statisticslbl.setFont(new Font("Tahoma", Font.BOLD, 25));
		Statisticslbl.setForeground(new Color(75, 150, 255));

		JPanel panel_textArea = new JPanel();
		panel_textArea.setBackground(Color.WHITE);
		panel_textArea.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		panel_textArea.setBorder(new LineBorder(new Color(75, 150, 255), 1, true));

		StatisticsET = new JTextArea();
		panel_textArea.add(StatisticsET);
		StatisticsET.setRows(8);
		StatisticsET.setEditable(false);

		StatisticsET.setFont(new Font("Tahoma", Font.PLAIN, 20));
		StatisticsET.setColumns(10);

		//menu panel
		JPanel menu = new JPanel();
		menu.setBorder(new EmptyBorder(0, 0, 0, 0));
		menu.setBackground(Color.WHITE);
		menu.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

		JButton loadBtn = new JButton("Load a Request");
		loadBtn.setFont(new Font("Tahoma", Font.PLAIN, 18));
		loadBtn.setActionCommand("upload");
		loadBtn.setForeground(new Color(75, 150, 255));
		loadBtn.setBackground(Color.LIGHT_GRAY);
		loadBtn.setFocusPainted(false);
		loadBtn.setIcon(
				new ImageIcon(CacheUnitView.class.getResource("/com/sun/java/swing/plaf/windows/icons/UpFolder.gif")));
		loadBtn.addActionListener(new CacheUnitPanel());
		menu.add(loadBtn);

		JButton statisticsBtn = new JButton("Show Statistics");
		statisticsBtn.setFont(new Font("Tahoma", Font.PLAIN, 18));
		statisticsBtn.setActionCommand("statistics");
		statisticsBtn.setForeground(new Color(75, 150, 255));
		statisticsBtn.setBackground(Color.LIGHT_GRAY);
		statisticsBtn.setIcon(new ImageIcon(
				CacheUnitView.class.getResource("/com/sun/javafx/scene/web/skin/UnorderedListBullets_16x16_JFX.png")));
		statisticsBtn.setFocusPainted(false);

		statisticsBtn.addActionListener(new CacheUnitPanel());
		menu.add(statisticsBtn);
		
		//order in Group Layout over the screen
		GroupLayout gl_operationPanel = new GroupLayout(topPanel);
		gl_operationPanel.setHorizontalGroup(gl_operationPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_operationPanel.createSequentialGroup().addGap(7)
						.addGroup(gl_operationPanel.createParallelGroup(Alignment.LEADING)
								.addComponent(panel_stat, GroupLayout.PREFERRED_SIZE, 500, GroupLayout.PREFERRED_SIZE)
								.addComponent(panel_r1, GroupLayout.PREFERRED_SIZE, 500, GroupLayout.PREFERRED_SIZE)
								.addComponent(panel_textArea, GroupLayout.PREFERRED_SIZE, 500,
										GroupLayout.PREFERRED_SIZE)
								.addComponent(menu, GroupLayout.PREFERRED_SIZE, 500, GroupLayout.PREFERRED_SIZE))));
		gl_operationPanel
				.setVerticalGroup(
						gl_operationPanel
								.createParallelGroup(
										Alignment.LEADING)
								.addGroup(gl_operationPanel.createSequentialGroup().addGap(7)
										.addComponent(panel_stat, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
												GroupLayout.PREFERRED_SIZE)
										.addGap(4)
										.addComponent(panel_r1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
												GroupLayout.PREFERRED_SIZE)
										.addGap(4)
										.addComponent(panel_textArea, GroupLayout.PREFERRED_SIZE, 226,
												GroupLayout.PREFERRED_SIZE)
										.addGap(4).addComponent(menu, GroupLayout.PREFERRED_SIZE, 75,
												GroupLayout.PREFERRED_SIZE)));
		topPanel.setLayout(gl_operationPanel);
		main.setVisible(true);

	}

	public void addPropertyChangeListener(PropertyChangeListener pcl) {
		listener.addPropertyChangeListener(pcl);
	}

	public void removePropertyChangeListener(PropertyChangeListener pcl) {
		listener.removePropertyChangeListener(pcl);
	}

	private void notifyListeners(PropertyChangeEvent evt) {
		listener.firePropertyChange(evt);
	}

	// Update the UI whit the information from server
	public <T> void updateUIData(T t) {
		String answer = (String) t;
		String arr[] = answer.split(",");
		String action[] = arr[0].split(":");
		if (action[1].equals("STATISTICS")) {
			StatisticsET.setText("");
			for (int i = 2; i < arr.length; i++) {
				StatisticsET.setText(StatisticsET.getText() + "\n" + arr[i]);
			}
		} else {
			String result[] = arr[1].split(":");
			JLabel message = new JLabel("The action " + action[1] + " was " + result[1] + "...");
			message.setFont(new Font("Arial", Font.BOLD, 18));
			UIManager.put("OptionPane.buttonFont", new Font("Arial", Font.BOLD, 18));
			JOptionPane.showMessageDialog(null, message, "Message From Server", JOptionPane.INFORMATION_MESSAGE);
		}
	}

	public class CacheUnitPanel extends JPanel implements ActionListener {

		private String parseJgonRequest(File file) {
			String request = null;
			try {
				BufferedReader in = new BufferedReader(new FileReader(file));
				Gson gson = new Gson();

				JsonObject req = gson.fromJson(in, JsonObject.class);
				request = req.toString();

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			return request;
		}

		@Override
		public void actionPerformed(ActionEvent event) {

			Thread thread = new Thread(new Runnable() {

				@Override
				public void run() {

					if (event.getActionCommand().equals("statistics")) {
						String message = "{   \"headers\": \r\n" + "{\"action\":\"STATISTICS\"}, \r\n"
								+ "    \"body\": \r\n" + "[{}]" + "}";
						notifyListeners(new PropertyChangeEvent(CacheUnitView.this, "", null, message));

					} else if (event.getActionCommand().equals("upload")) {
						JFileChooser fileChooser = new JFileChooser();
						fileChooser.setDialogTitle("Upload Json Request...");

						FileFilter filter = new FileNameExtensionFilter("Json File", "json");
						fileChooser.setAcceptAllFileFilterUsed(false);
						fileChooser.addChoosableFileFilter(filter);
						int result = fileChooser.showOpenDialog(main);
						if (result == JFileChooser.APPROVE_OPTION) {
							File selectedFile = fileChooser.getSelectedFile();
							String request = parseJgonRequest(selectedFile);
							notifyListeners(new PropertyChangeEvent(CacheUnitView.this, "", null, request));
						}

					}
				}
			});
			thread.start();
		}
	}
}
