package com.hit.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;

import com.hit.dm.DataModel;


//System secondary memory (file)
//Access to it takes more time and resources from the system
//Cached Hash Map For quick search among all DataModels

public class DaoFileImpl<T> implements IDao<Long, DataModel<T>> {

	private String filePath;
	private HashMap<Long, DataModel<T>> map;

	public DaoFileImpl(String filePath) { // Constructor

		this.filePath = filePath;

		File file = new File(filePath);
		if (!file.exists()) { // file doesn't exist

			map = new HashMap<>();
			for (int i = 1; i < 1000; i++) //Production of address space (1-999)
				map.put((long)i, new DataModel<T>((long)i, null));
			try {
				ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filePath));
				out.writeObject(map);
				out.flush();
				out.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

		} else {
			try {
				ObjectInputStream in = new ObjectInputStream(new FileInputStream(filePath));
				map = (HashMap<Long, DataModel<T>>) in.readObject();
				in.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}

	}
	
	//Get update version of memory
	private void updateMap() {
		try {
			ObjectInputStream in = new ObjectInputStream(new FileInputStream(filePath));
			map = (HashMap<Long, DataModel<T>>) in.readObject();
			in.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void delete(DataModel<T> entity) {
		updateMap();
		map.remove(entity.getDataModelId());
		try {
			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filePath));
			out.writeObject(map);
			out.flush();
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void save(DataModel<T> entity) {
		updateMap();
		map.put(entity.getDataModelId(), entity);
		try {
			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filePath));
			out.writeObject(map);
			out.flush();
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public DataModel<T> find(Long id) {
		updateMap();
		return map.get(id);
	}

}
