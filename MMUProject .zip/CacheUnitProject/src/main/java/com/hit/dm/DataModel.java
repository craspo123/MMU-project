package com.hit.dm;

import java.io.Serializable;

public class DataModel<T> implements Serializable
{
	private long dataModelId;
	private T content;
	
	public DataModel(Long id, T content)
	{
		this.dataModelId=id;
		this.content=content;
	}
	
	public T getContent() 
	{
		return content;
	}
	
	public void setContent(T content)
	{
		this.content=content;
	}
	
	public long getDataModelId() 
	{
		return dataModelId;
	}
	
	public void setDataModelId(long id)
	{
		this.dataModelId=id;
	}
}
