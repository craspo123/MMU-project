package com.hit.memory;

import java.util.ArrayList;

import com.hit.algorithm.IAlgoCache;
import com.hit.dm.DataModel;

public class CacheUnit<T> {
	
	private IAlgoCache<Long, DataModel<T>> algo;

	public CacheUnit(IAlgoCache<Long, DataModel<T>> algo) {
		this.algo = algo;
	}

	public DataModel<T>[] getDataModels(Long[] ids) {
		
		DataModel<T>[] arr= new DataModel[ids.length];
		
		for(int i=0;i<ids.length;i++)
		{
			arr[i]=algo.getElement(ids[i]);
		}
		
		return arr;
	}

	public DataModel<T>[] putDataModels(DataModel<T>[] datamodels) {
		
		ArrayList<DataModel<T>> arr= new ArrayList<>();
		for(int i=0;i<datamodels.length;i++)
		{
			DataModel<T> ret=algo.putElement(datamodels[i].getDataModelId(), datamodels[i]);
			if(ret!=null)
			{
				arr.add(ret);
			}
		}
		
		DataModel<T>[] arr1=new DataModel[arr.size()];
		
		for(int i=0;i<arr.size();i++)
		{
			arr1[i]=arr.get(i);
		}
		return arr1;

	}

	public void removeDataModels(Long[] ids) {
		
		for(int i=0;i<ids.length;i++)
		{
			algo.removeElement(ids[i]);
		}

	}

}
