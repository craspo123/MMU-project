package com.hit.server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Type;
import java.net.Socket;
import java.util.HashMap;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hit.dm.DataModel;
import com.hit.services.CacheUnitController;

//Its purpose is to handle clients requests
//Identifies the type of request and handles it accordingly
public class HandleRequest<T> implements Runnable {

	private Socket incoming;
	private CacheUnitController<T> controller;

	public HandleRequest(Socket s, CacheUnitController<T> controller) {
		this.incoming = s;
		this.controller = controller;
	}

	// Jason request conversion
	private Request<DataModel<T>[]> parseToRequest(String req) {
		Type ref = new TypeToken<Request<DataModel<T>[]>>() {
		}.getType();
		Request<DataModel<T>[]> request = new Gson().fromJson(req, ref);
		return request;
	}

	@Override
	public void run() {

		final String ACTION = "action", RESULT = "Result", UPDATE = "UPDATE", GET = "GET", DELETE = "DELETE",
				STATISTICS = "STATISTICS", SUCCEEDED = "succeeded", FAILED = "failed";

		ObjectInputStream inFromClient = null;
		ObjectOutputStream outToClient = null;

		try {

			// Opening communication lines between the handler and the client
			inFromClient = new ObjectInputStream(incoming.getInputStream());
			outToClient = new ObjectOutputStream(incoming.getOutputStream());

			// Receiving and parsing the request from the client
			String req = (String) inFromClient.readObject();
			Request<DataModel<T>[]> request = parseToRequest(req);

			if ((request != null) && (request.getHeaders() != null)) {
				String action = request.getHeaders().get(ACTION).toUpperCase();

				HashMap<String, String> answer = new HashMap<>();
				HashMap<String, String> statistics = new HashMap<>();

				Boolean is_success = true;

				if (action.equals(UPDATE)) {
					answer.put(ACTION, UPDATE);
					is_success = controller.update((DataModel<T>[]) request.getBody());
				}

				else if (action.equals(GET)) {
					answer.put(ACTION, GET);
					DataModel<T>[] body = controller.get((DataModel<T>[]) request.getBody());
					// TODO: send to client the required data models
				}

				else if (action.equals(DELETE)) {
					answer.put(ACTION, DELETE);
					is_success = controller.delete((DataModel<T>[]) request.getBody());
				}

				else if (action.equals(STATISTICS)) {
					answer.put(ACTION, STATISTICS);
					statistics = controller.getStatistics();
					answer.putAll(statistics);
				}

				if (is_success)
					answer.put(RESULT, SUCCEEDED);
				else
					answer.put(RESULT, FAILED);

				outToClient.writeObject(answer);

				inFromClient.close();
				outToClient.close();
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
