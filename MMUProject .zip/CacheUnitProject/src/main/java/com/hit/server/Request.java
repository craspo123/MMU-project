package com.hit.server;

import java.io.Serializable;
import java.util.Map;

//All requests from the system are described by this class
public class Request<T> implements Serializable {

	private T body;
	private Map<String,String> headers;
	
	
	public Request(Map<String,String> headers,T body) {
		this.body=body;
		this.headers=headers;	
	}
	
	public Map<String,String> getHeaders() { return headers; }
	
	public void setHeaders(Map<String,String> headers) { this.headers=headers; }
	
	public T getBody() { return body; }
	
	public void setBody(T body) { this.body=body; }

	//Json formats
	@Override
	public String toString() {
		return "headers:" + headers +"\n"+"body:"+body.toString();
	}
	
}
