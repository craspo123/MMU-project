package com.hit.server;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import com.hit.services.CacheUnitController;

public class Server implements PropertyChangeListener, Runnable
{

	private boolean is_listening = true;
	private CacheUnitController<String> controller = new CacheUnitController<>();
	private Thread currentThread;
	
	@Override
	public void run() {
		try {
			ServerSocket server = new ServerSocket(12345);
			Executor excutor = Executors.newFixedThreadPool(10);
			Socket incoming = null;

			while (is_listening) {
				try {
					incoming = server.accept();
					excutor.execute(new HandleRequest<String>(incoming, controller));

				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}	
	}

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		if (evt.getNewValue().toString().equals("start")) {
			is_listening = true;
			if ((currentThread == null) || (!currentThread.isAlive())) {
				currentThread = new	Thread(this);
				currentThread.start();
			}
		} else if (evt.getNewValue().toString().equals("shutdown")) {
			is_listening = false;
		}
		
	}

}
