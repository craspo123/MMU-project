package com.hit.services;

import java.util.HashMap;

import com.hit.dm.DataModel;

//This layer abstraction of the system
//Its function is to transfer information between the handler and the service
public class CacheUnitController<T> {

	private CacheUnitService<T> service;

	public CacheUnitController() {
		service = new CacheUnitService<>();
	}

	public boolean update(DataModel<T>[] dataModels) {
		return service.update(dataModels);
	}

	public boolean delete(DataModel<T>[] dataModels) {
		return service.delete(dataModels);
	}

	public DataModel<T>[] get(DataModel<T>[] dataModels) {
		return service.get(dataModels);
	}
	
	public HashMap<String,String> getStatistics(){
		return service.getStatistics();
	}
}
