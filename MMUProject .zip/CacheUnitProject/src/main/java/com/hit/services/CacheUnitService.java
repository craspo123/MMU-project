package com.hit.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;

import com.hit.algorithm.NRUAlgoCacheImpl;
import com.hit.dao.DaoFileImpl;
import com.hit.dao.IDao;
import com.hit.dm.DataModel;
import com.hit.memory.CacheUnit;

public class CacheUnitService<T> {

	private static final String FILE_PATH = "src\\main\\resources\\DataSource.txt";
	private CacheUnit<T> unit;
	private IDao idao;
	private HashMap<String, String> statistics = new HashMap<>();
	private AtomicInteger numOfRequest, DataModels, numOfSwaps;
	private final String CAPACITY = "Capacity", ALGO = "Algo", DATAMODEL = "DataModel", REQUEST = "Request",
			SWAPS = "Swaps";

	public CacheUnitService() {
		numOfRequest = new AtomicInteger(0);
		DataModels = new AtomicInteger(0);
		numOfSwaps = new AtomicInteger(0);
		unit = new CacheUnit(new NRUAlgoCacheImpl<>(5));
		idao = new DaoFileImpl<T>(FILE_PATH);

		statistics.put(CAPACITY, "5");
		statistics.put(ALGO, "NRU");
		statistics.put(DATAMODEL, DataModels + "");
		statistics.put(REQUEST, numOfRequest + "");
		statistics.put(SWAPS, "0");
	}

	public boolean update(DataModel<T>[] dataModels) {

		Long ids[] = getIds(dataModels);
		DataModel<T>[] Models = getAllDataModels(ids);

		for (int j = 0; j < Models.length; j++)
			Models[j].setContent(dataModels[j].getContent());

		updateStatistics(dataModels.length);
		return true;
	}
	
	public boolean delete(DataModel<T>[] dataModels) {

		Long ids[] = getIds(dataModels);
		DataModel<T>[] Models = getAllDataModels(ids);

		for (int j = 0; j < Models.length; j++)
			Models[j].setContent(null);

		updateStatistics(dataModels.length);
		return true;
	}
	
	public DataModel<T>[] get(DataModel<T>[] dataModels) {

		Long ids[] = getIds(dataModels);
		DataModel<T>[] Models = getAllDataModels(ids);
		
		for (int j = 0; j < Models.length; j++) {
			dataModels[j].setContent(Models[j].getContent());
		}

		updateStatistics(dataModels.length);
		return dataModels;
	}
	
	//Manage and synchronize primary memory and secondary memory
	private DataModel<T>[] getAllDataModels(Long[] ids) {
		DataModel<T>[] Models = null;
		ArrayList<DataModel<T>> ModelsNotInCache = new ArrayList();
		DataModel<T>[] ModelsNotInCacheArray = null;
		DataModel<T>[] ModelsToUpdateInFile = null;
		Models = unit.getDataModels(ids);//find in Cache

		for (int j = 0; j < Models.length; j++) {
			if (Models[j] == null) {// DM not in the cache so get from the file
				Models[j] = (DataModel<T>) idao.find(ids[j]);
				ModelsNotInCache.add(Models[j]);
			}
		}

		ModelsNotInCacheArray = new DataModel[ModelsNotInCache.size()];
		ModelsToUpdateInFile = new DataModel[ModelsNotInCache.size()];
		for (int i = 0; i < ModelsNotInCache.size(); i++) {
			ModelsNotInCacheArray[i] = ModelsNotInCache.get(i);
		}

		ModelsToUpdateInFile = unit.putDataModels(ModelsNotInCacheArray);// update the file
		for (int i = 0; i < ModelsToUpdateInFile.length; i++) {
			if (ModelsToUpdateInFile[i] != null) {
				idao.save(ModelsToUpdateInFile[i]);
				numOfSwaps.incrementAndGet();
			}
		}
		
		return Models;
	}

	private Long[] getIds(DataModel<T>[] dataModels) {

		Long ids[] = new Long[dataModels.length];
		int i = 0;
		for (DataModel<T> data : dataModels) {
			ids[i] = data.getDataModelId();
			i++;
		}

		return ids;
	}

	// Synchronization mechanism to maintain the critical section
	private synchronized void updateStatistics(int numOfDataModels) {

		numOfRequest.incrementAndGet();
		DataModels.getAndSet(DataModels.get() + numOfDataModels);
		statistics.put(SWAPS, numOfSwaps.intValue() + "");
		statistics.put(REQUEST, numOfRequest.intValue() + "");
		statistics.put(DATAMODEL, DataModels.intValue() + "");
	}

	public HashMap<String, String> getStatistics() {
		return statistics;
	}
}
