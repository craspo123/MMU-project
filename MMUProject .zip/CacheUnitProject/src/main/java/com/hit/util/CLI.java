package com.hit.util;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class CLI implements Runnable {

	private InputStream in;
	private OutputStream out;
	private PropertyChangeSupport listener = new PropertyChangeSupport(this);
	

	public CLI(InputStream in, OutputStream out) {
		this.in = in;
		this.out = out;
		
	}

	@Override
	public void run() {
		// messages
		final String SCAN_COMMAND = "Please enter your command";
		final String START_SERVER = "Starting server...";
		final String STOP_SERVER = "Shutdown server";
		final String NOT_VALID = "Not a valid command";

		Scanner scanner = new Scanner(in);

		while (true) {

			write(SCAN_COMMAND);
			String command = scanner.nextLine();
			command = command.toLowerCase().trim();

			if (command.equals("start")) {
				write(START_SERVER);
				notifyListeners(new PropertyChangeEvent(this,"ServerStatus",null,"start"));
			} else if (command.equals("Shutdown")) {
				write(STOP_SERVER);
				notifyListeners(new PropertyChangeEvent(this,"ServerStatus",null,"Shutdown"));
			} else {
				write(NOT_VALID);
			}
		}

	}

	public void addPropertyChangeListener(PropertyChangeListener pcl) {
		listener.addPropertyChangeListener(pcl);
		
	}

	public void removePropertyChangeListener(PropertyChangeListener pcl) {
		listener.removePropertyChangeListener(pcl);
	}
	
	private void notifyListeners(PropertyChangeEvent evt) {
		listener.firePropertyChange(evt);
	}

	public void write(String string) {
		PrintWriter writer = new PrintWriter(out);
		writer.println(string);
		writer.flush();
	}

}
