package com.hit.memory;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.hit.algorithm.NRUAlgoCacheImpl;
import com.hit.dao.DaoFileImpl;
import com.hit.dao.IDao;
import com.hit.dm.DataModel;

class CacheUnitTest {
	
	private static final String FILE_PATH = "src\\main\\resources\\DataSource.txt";
	private static CacheUnit<String> unit;
	private static IDao<Long, DataModel<String>> idao;


	@BeforeAll
	static void setUp() throws Exception {
		unit = new CacheUnit<String>(new NRUAlgoCacheImpl<>(2));
		idao = new DaoFileImpl<String>(FILE_PATH);
	}

	@Test
	void updateTest() {
		DataModel<String>[] dataModelsToUpdate=new DataModel[4];
		dataModelsToUpdate[0]=new DataModel<String>((long) 100, "100");
		dataModelsToUpdate[1]=new DataModel<String>((long) 200, "200");
		dataModelsToUpdate[2]=new DataModel<String>((long) 300, "300");
		dataModelsToUpdate[3]=new DataModel<String>((long) 400, "400");
		
		DataModel<String>[] dataModelsToSaveInFile=unit.putDataModels(dataModelsToUpdate);
		for (int i = 0; i < dataModelsToSaveInFile.length; i++) {
			if(dataModelsToSaveInFile[i]!=null) {
				idao.save(dataModelsToSaveInFile[i]);
			}
		}
		
		assertEquals("400", unit.getDataModels(new Long[]{(long) 400})[0].getContent());
		assertEquals("100", ((DataModel<String>) idao.find((long)100)).getContent());
	}
	
	@Test
	void deleteTest() {
		DataModel<String>[] dataModelsToDelete=new DataModel[2];
		dataModelsToDelete[0]=new DataModel<String>((long) 300, "300");
		dataModelsToDelete[1]=new DataModel<String>((long) 400, "400");
		
		Long[] ids=new Long[2];
		ids[0]=(long) 300;
		ids[1]=(long) 400;
		unit.removeDataModels(ids);
		assertEquals(null, unit.getDataModels(ids)[0]);
		
		idao.delete(dataModelsToDelete[0]);
		DataModel<String> dm=(DataModel<String>) idao.find((long)300);
		assertEquals(null,dm);
	}
	
	@Test
	void getTest() {
		Long[] ids=new Long[1];
		ids[0]=(long) 400;
		
		updateTest();
		DataModel<String>[] dataModels=unit.getDataModels(ids);
		assertEquals("400", dataModels[0].getContent());
		
		DataModel<String> dm=(DataModel<String>) idao.find((long)300);
		assertEquals("300", dm.getContent());
	}
}
